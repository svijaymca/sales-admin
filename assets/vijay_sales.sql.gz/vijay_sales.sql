-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 04, 2018 at 08:45 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vijay_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `branchId` int(11) NOT NULL AUTO_INCREMENT,
  `branchUniqId` varchar(20) NOT NULL,
  `branchCode` varchar(10) NOT NULL,
  `branchName` varchar(100) NOT NULL,
  `branchLineNo` varchar(13) NOT NULL,
  `branchEmail` varchar(50) NOT NULL,
  `branchGstNo` varchar(15) NOT NULL,
  `branchAddress` varchar(255) NOT NULL,
  `branchAddedBy` int(11) NOT NULL,
  `branchAddedOn` int(11) NOT NULL,
  `branchAddedIp` varchar(20) NOT NULL,
  `branchModifiedBy` int(11) NOT NULL,
  `branchModifiedOn` int(11) NOT NULL,
  `branchModifiedIp` varchar(20) NOT NULL,
  `branchDeletedBy` int(11) NOT NULL,
  `branchDeletedOn` int(11) NOT NULL,
  `branchDeletedIp` varchar(20) NOT NULL,
  `branchStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`branchId`),
  UNIQUE KEY `branchUniqId` (`branchUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `customerUniqId` varchar(20) NOT NULL,
  `customerCode` varchar(10) NOT NULL,
  `customerName` varchar(100) NOT NULL,
  `customerAddress` varchar(255) NOT NULL,
  `customerMobileNo` varchar(13) NOT NULL,
  `customerEmail` varchar(50) NOT NULL,
  `customerGstNo` varchar(15) NOT NULL,
  `customerAddedBy` int(11) NOT NULL,
  `customerAddedOn` int(11) NOT NULL,
  `customerAddedIp` varchar(20) NOT NULL,
  `customerModifiedBy` int(11) NOT NULL,
  `customerModifiedOn` int(11) NOT NULL,
  `customerModifiedIp` varchar(20) NOT NULL,
  `customerDeletedBy` int(11) NOT NULL,
  `customerDeletedOn` int(11) NOT NULL,
  `customerDeletedIp` varchar(20) NOT NULL,
  `customerStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `customerUniqId` (`customerUniqId`),
  UNIQUE KEY `customerCode` (`customerCode`),
  UNIQUE KEY `customerGstNo` (`customerGstNo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE IF NOT EXISTS `invoice` (
  `invoiceId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceUniqId` varchar(20) NOT NULL,
  `invoiceNo` varchar(10) NOT NULL,
  `invoiceDate` varchar(20) NOT NULL,
  `invoiceCustomerId` int(11) NOT NULL,
  `invoiceTaxType` int(11) NOT NULL,
  `invoiceGrossTotal` decimal(12,2) NOT NULL,
  `invoiceCgstPer` decimal(12,2) NOT NULL,
  `invoiceCgstAmount` decimal(12,2) NOT NULL,
  `invoiceSgstPer` decimal(12,2) NOT NULL,
  `invoiceSgstAmount` decimal(12,2) NOT NULL,
  `invoiceIgstPer` decimal(12,2) NOT NULL,
  `invoiceIgstAmount` decimal(12,2) NOT NULL,
  `invoiceOtherTaxPer` decimal(12,2) NOT NULL,
  `invoiceOtherTaxAmount` decimal(12,2) NOT NULL,
  `invoiceDiscountPer` decimal(12,2) NOT NULL,
  `invoiceDiscountAmount` decimal(12,2) NOT NULL,
  `invoiceNetTotal` decimal(12,2) NOT NULL,
  `invoiceRemarks` varchar(255) NOT NULL,
  `invoiceBranchId` int(11) NOT NULL,
  `invoiceAddedBy` int(11) NOT NULL,
  `invoiceAddedOn` int(11) NOT NULL,
  `invoiceAddedIp` varchar(20) NOT NULL,
  `invoiceModifiedBy` int(11) NOT NULL,
  `invoiceModifiedOn` int(11) NOT NULL,
  `invoiceModifiedIp` varchar(20) NOT NULL,
  `invoiceDeletedBy` int(11) NOT NULL,
  `invoiceDeletedOn` int(11) NOT NULL,
  `invoiceDeletedIp` varchar(20) NOT NULL,
  `invoiceStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`invoiceId`),
  UNIQUE KEY `invoiceUniqId` (`invoiceUniqId`),
  KEY `invoiceCustomerId` (`invoiceCustomerId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `invoicedetails`
--

CREATE TABLE IF NOT EXISTS `invoicedetails` (
  `invoiceDetailsId` int(11) NOT NULL AUTO_INCREMENT,
  `invoiceDetailsUniqId` varchar(20) NOT NULL,
  `invoiceDetailsInvoiceId` int(11) NOT NULL,
  `invoiceDetailsProductId` int(11) NOT NULL,
  `invoiceDetailsQty` decimal(12,3) NOT NULL,
  `invoiceDetailsRate` decimal(12,2) NOT NULL,
  `invoiceDetailsAmount` decimal(12,2) NOT NULL,
  `invoiceDetailsAddedBy` int(11) NOT NULL,
  `invoiceDetailsAddedOn` int(11) NOT NULL,
  `invoiceDetailsAddedIp` varchar(20) NOT NULL,
  `invoiceDetailsModifiedBy` int(11) NOT NULL,
  `invoiceDetailsModifiedOn` int(11) NOT NULL,
  `invoiceDetailsModifiedIp` varchar(20) NOT NULL,
  `invoiceDetailsDeletedBy` int(11) NOT NULL,
  `invoiceDetailsDeletedOn` int(11) NOT NULL,
  `invoiceDetailsDeletedIp` varchar(20) NOT NULL,
  `invoiceDetailsStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`invoiceDetailsId`),
  UNIQUE KEY `invoiceDetailsUniqId` (`invoiceDetailsUniqId`),
  KEY `invoiceDetailsProductId` (`invoiceDetailsProductId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `productId` int(11) NOT NULL AUTO_INCREMENT,
  `productUniqId` varchar(20) NOT NULL,
  `productCode` varchar(10) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `productRate` decimal(12,2) NOT NULL,
  `productAddedBy` int(11) NOT NULL,
  `productAddedOn` int(11) NOT NULL,
  `productAddedIp` varchar(20) NOT NULL,
  `productModifiedBy` int(11) NOT NULL,
  `productModifiedOn` int(11) NOT NULL,
  `productModifiedIp` varchar(20) NOT NULL,
  `productDeletedBy` int(11) NOT NULL,
  `productDeletedOn` int(11) NOT NULL,
  `productDeletedIp` varchar(20) NOT NULL,
  `productStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`productId`),
  UNIQUE KEY `productUniqId` (`productUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `purchaseId` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseUniqId` varchar(20) NOT NULL,
  `purchaseNo` varchar(10) NOT NULL,
  `purchaseDate` varchar(20) NOT NULL,
  `purchaseSupplierId` int(11) NOT NULL,
  `purchaseTaxType` int(11) NOT NULL,
  `purchaseGrossTotal` decimal(12,2) NOT NULL,
  `purchaseCgstPer` decimal(12,2) NOT NULL,
  `purchaseCgstAmount` decimal(12,2) NOT NULL,
  `purchaseSgstPer` decimal(12,2) NOT NULL,
  `purchaseSgstAmount` decimal(12,2) NOT NULL,
  `purchaseIgstPer` decimal(12,2) NOT NULL,
  `purchaseIgstAmount` decimal(12,2) NOT NULL,
  `purchaseOtherTaxPer` decimal(12,2) NOT NULL,
  `purchaseOtherTaxAmount` decimal(12,2) NOT NULL,
  `purchaseDiscountPer` decimal(12,2) NOT NULL,
  `purchaseDiscountAmount` decimal(12,2) NOT NULL,
  `purchaseNetTotal` decimal(12,2) NOT NULL,
  `purchaseRemarks` varchar(255) NOT NULL,
  `purchaseBranchId` int(11) NOT NULL,
  `purchaseAddedBy` int(11) NOT NULL,
  `purchaseAddedOn` int(11) NOT NULL,
  `purchaseAddedIp` varchar(20) NOT NULL,
  `purchaseModifiedBy` int(11) NOT NULL,
  `purchaseModifiedOn` int(11) NOT NULL,
  `purchaseModifiedIp` varchar(20) NOT NULL,
  `purchaseDeletedBy` int(11) NOT NULL,
  `purchaseDeletedOn` int(11) NOT NULL,
  `purchaseDeletedIp` varchar(20) NOT NULL,
  `purchaseStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`purchaseId`),
  UNIQUE KEY `purchaseUniqId` (`purchaseUniqId`),
  KEY `purchaseSupplierId` (`purchaseSupplierId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE IF NOT EXISTS `purchasedetails` (
  `purchaseDetailsId` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseDetailsUniqId` varchar(20) NOT NULL,
  `purchaseDetailsPurchaseId` int(11) NOT NULL,
  `purchaseDetailsProductId` int(11) NOT NULL,
  `purchaseDetailsQty` decimal(12,3) NOT NULL,
  `purchaseDetailsRate` decimal(12,2) NOT NULL,
  `purchaseDetailsAmount` decimal(12,2) NOT NULL,
  `purchaseDetailsAddedBy` int(11) NOT NULL,
  `purchaseDetailsAddedOn` int(11) NOT NULL,
  `purchaseDetailsAddedIp` varchar(20) NOT NULL,
  `purchaseDetailsModifiedBy` int(11) NOT NULL,
  `purchaseDetailsModifiedOn` int(11) NOT NULL,
  `purchaseDetailsModifiedIp` varchar(20) NOT NULL,
  `purchaseDetailsDeletedBy` int(11) NOT NULL,
  `purchaseDetailsDeletedOn` int(11) NOT NULL,
  `purchaseDetailsDeletedIp` varchar(20) NOT NULL,
  `purchaseDetailsStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`purchaseDetailsId`),
  UNIQUE KEY `purchaseDetailsUniqId` (`purchaseDetailsUniqId`),
  KEY `purchaseDetailsProductId` (`purchaseDetailsProductId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Table structure for table `stockledger`
--

CREATE TABLE IF NOT EXISTS `stockledger` (
  `stockLedgerId` int(11) NOT NULL AUTO_INCREMENT,
  `stockLedgerType` varchar(5) NOT NULL,
  `stockLedgerEntryId` int(11) NOT NULL,
  `stockLedgerDetailId` int(11) NOT NULL,
  `stockLedgerDate` date NOT NULL,
  `stockLedgerProductId` int(11) NOT NULL,
  `stockLedgerQty` decimal(12,3) NOT NULL,
  `stockLedgerBranchId` tinyint(4) NOT NULL,
  `stockLedgerAddedBy` tinyint(4) NOT NULL,
  `stockLedgerAddedOn` int(11) NOT NULL,
  `stockLedgerAddedIp` varchar(20) NOT NULL,
  `stockLedgerModifiedBy` tinyint(4) NOT NULL,
  `stockLedgerModifiedOn` int(11) NOT NULL,
  `stockLedgerModifiedIp` varchar(20) NOT NULL,
  `stockLedgerDeletedBy` tinyint(4) NOT NULL,
  `stockLedgerDeletedOn` int(11) NOT NULL,
  `stockLedgerDeletedIp` varchar(20) NOT NULL,
  `stockLedgerStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`stockLedgerId`),
  KEY `stockLedgerEntryId` (`stockLedgerEntryId`),
  KEY `stockLedgerDetailId` (`stockLedgerDetailId`),
  KEY `stockLedgerStatus` (`stockLedgerStatus`),
  KEY `stockLedgerProductId` (`stockLedgerProductId`),
  KEY `stockLedgerBranchId` (`stockLedgerBranchId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplierId` int(11) NOT NULL AUTO_INCREMENT,
  `supplierUniqId` varchar(20) NOT NULL,
  `supplierCode` varchar(10) NOT NULL,
  `supplierName` varchar(100) NOT NULL,
  `supplierAddress` varchar(255) NOT NULL,
  `supplierMobileNo` varchar(13) NOT NULL,
  `supplierEmail` varchar(50) NOT NULL,
  `supplierGstNo` varchar(15) NOT NULL,
  `supplierAddedBy` int(11) NOT NULL,
  `supplierAddedOn` int(11) NOT NULL,
  `supplierAddedIp` varchar(20) NOT NULL,
  `supplierModifiedBy` int(11) NOT NULL,
  `supplierModifiedOn` int(11) NOT NULL,
  `supplierModifiedIp` varchar(20) NOT NULL,
  `supplierDeletedBy` int(11) NOT NULL,
  `supplierDeletedOn` int(11) NOT NULL,
  `supplierDeletedIp` varchar(20) NOT NULL,
  `supplierStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`supplierId`),
  UNIQUE KEY `supplierUniqId` (`supplierUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_status` varchar(10) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
