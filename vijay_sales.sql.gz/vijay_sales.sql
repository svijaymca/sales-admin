-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 14, 2018 at 06:32 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vijay_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `branchId` int(11) NOT NULL AUTO_INCREMENT,
  `branchUniqId` varchar(20) NOT NULL,
  `branchCode` varchar(10) NOT NULL,
  `branchName` varchar(100) NOT NULL,
  `branchLineNo` varchar(13) NOT NULL,
  `branchEmail` varchar(50) NOT NULL,
  `branchGstNo` varchar(15) NOT NULL,
  `branchAddress` varchar(255) NOT NULL,
  `branchAddedBy` int(11) NOT NULL,
  `branchAddedOn` int(11) NOT NULL,
  `branchAddedIp` varchar(20) NOT NULL,
  `branchModifiedBy` int(11) NOT NULL,
  `branchModifiedOn` int(11) NOT NULL,
  `branchModifiedIp` varchar(20) NOT NULL,
  `branchDeletedBy` int(11) NOT NULL,
  `branchDeletedOn` int(11) NOT NULL,
  `branchDeletedIp` varchar(20) NOT NULL,
  `branchStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`branchId`),
  UNIQUE KEY `branchUniqId` (`branchUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branchId`, `branchUniqId`, `branchCode`, `branchName`, `branchLineNo`, `branchEmail`, `branchGstNo`, `branchAddress`, `branchAddedBy`, `branchAddedOn`, `branchAddedIp`, `branchModifiedBy`, `branchModifiedOn`, `branchModifiedIp`, `branchDeletedBy`, `branchDeletedOn`, `branchDeletedIp`, `branchStatus`) VALUES
(1, 'y4umblSMVD9svQRo30ZC', 'B0001', 'Dindigul', '0451234506', 'dindigul@gmail.com', '33dgl123dgl3213', 'Near Bustand,  Dindigul - 624701.', 1, 1518715767, '192.168.1.7', 1, 1518715787, '192.168.1.7', 0, 0, '', 0),
(2, 'l0X4BUy1JGtDrNanvTPo', 'B0002', 'Chennai', '0441234561', 'chennai@gmail.com', '33CHN123dgl3213', 'Ambattur, Chennai - 600001.', 1, 1518800922, '192.168.1.7', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customerId` int(11) NOT NULL AUTO_INCREMENT,
  `customerUniqId` varchar(20) NOT NULL,
  `customerCode` varchar(10) NOT NULL,
  `customerName` varchar(100) NOT NULL,
  `customerAddress` varchar(255) NOT NULL,
  `customerMobileNo` varchar(13) NOT NULL,
  `customerEmail` varchar(50) NOT NULL,
  `customerGstNo` varchar(15) NOT NULL,
  `customerAddedBy` int(11) NOT NULL,
  `customerAddedOn` int(11) NOT NULL,
  `customerAddedIp` varchar(20) NOT NULL,
  `customerModifiedBy` int(11) NOT NULL,
  `customerModifiedOn` int(11) NOT NULL,
  `customerModifiedIp` varchar(20) NOT NULL,
  `customerDeletedBy` int(11) NOT NULL,
  `customerDeletedOn` int(11) NOT NULL,
  `customerDeletedIp` varchar(20) NOT NULL,
  `customerStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`customerId`),
  UNIQUE KEY `customerUniqId` (`customerUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerId`, `customerUniqId`, `customerCode`, `customerName`, `customerAddress`, `customerMobileNo`, `customerEmail`, `customerGstNo`, `customerAddedBy`, `customerAddedOn`, `customerAddedIp`, `customerModifiedBy`, `customerModifiedOn`, `customerModifiedIp`, `customerDeletedBy`, `customerDeletedOn`, `customerDeletedIp`, `customerStatus`) VALUES
(1, 'vpPKuw4VFjZdhCX8smRA', 'fr', 'dth', '', '', '', '', 1, 1518454592, '192.168.1.7', 0, 0, '', 1, 1518454599, '192.168.1.7', 1),
(2, 'buVWxmP01MYgGTqfIE7K', 'C00001', 'Vijay', 'DINDIGUL', '9566600704', 'stsvjy@gmail.com', '33JGIGKJGKUGJGK', 1, 1518454678, '192.168.1.7', 0, 0, '', 0, 0, '', 0),
(3, 'ec0nWCbVQGgSdXNyAx4l', 'C00002', 'veera', 'Dindigul', '9876543210', 'veeramuthu@gmail.com', '33JGIGKJGKUGJGf', 1, 1518457014, '192.168.1.7', 1, 1518457475, '192.168.1.7', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `productId` int(11) NOT NULL AUTO_INCREMENT,
  `productUniqId` varchar(20) NOT NULL,
  `productCode` varchar(10) NOT NULL,
  `productName` varchar(100) NOT NULL,
  `productRate` decimal(12,2) NOT NULL,
  `productAddedBy` int(11) NOT NULL,
  `productAddedOn` int(11) NOT NULL,
  `productAddedIp` varchar(20) NOT NULL,
  `productModifiedBy` int(11) NOT NULL,
  `productModifiedOn` int(11) NOT NULL,
  `productModifiedIp` varchar(20) NOT NULL,
  `productDeletedBy` int(11) NOT NULL,
  `productDeletedOn` int(11) NOT NULL,
  `productDeletedIp` varchar(20) NOT NULL,
  `productStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`productId`),
  UNIQUE KEY `productUniqId` (`productUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productId`, `productUniqId`, `productCode`, `productName`, `productRate`, `productAddedBy`, `productAddedOn`, `productAddedIp`, `productModifiedBy`, `productModifiedOn`, `productModifiedIp`, `productDeletedBy`, `productDeletedOn`, `productDeletedIp`, `productStatus`) VALUES
(1, 'n5Oym9D7eV4EUTxPrRtC', 'P0001', 'PEN', 10.00, 1, 1518114874, '192.168.1.7', 1, 1518114898, '192.168.1.7', 1, 1518451882, '192.168.1.7', 1),
(2, 'eUZg83WQIuMvX6qoSORh', 'P00001', 'PEN', 10.00, 1, 1518452383, '192.168.1.7', 1, 1518459099, '192.168.1.7', 0, 0, '', 0),
(3, 'DWil2K3HpTMwY89SLsaC', 'P00002', 'PENCILE', 20.00, 1, 1518452397, '192.168.1.7', 0, 0, '', 1, 1518452434, '192.168.1.7', 1),
(4, 'ciDOuMv4P9VJgz8a6XqQ', 'P00002', 'Scale', 30.00, 1, 1518452468, '192.168.1.7', 0, 0, '', 1, 1518452472, '192.168.1.7', 1),
(5, 'MSOIAeCnp3d7vHQktr0h', 'P00002', 'PENCILE', 5.00, 1, 1518458882, '192.168.1.7', 0, 0, '', 0, 0, '', 0),
(6, 'fM7HKh2PRquVLWngQlX6', 'p00003', 'scale', 20.00, 1, 1518458950, '192.168.1.7', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE IF NOT EXISTS `purchase` (
  `purchaseId` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseUniqId` varchar(20) NOT NULL,
  `purchaseNo` varchar(10) NOT NULL,
  `purchaseDate` varchar(20) NOT NULL,
  `purchaseSupplierId` int(11) NOT NULL,
  `purchaseTaxType` int(11) NOT NULL,
  `purchaseGrossTotal` decimal(12,2) NOT NULL,
  `purchaseCgstPer` decimal(12,2) NOT NULL,
  `purchaseCgstAmount` decimal(12,2) NOT NULL,
  `purchaseSgstPer` decimal(12,2) NOT NULL,
  `purchaseSgstAmount` decimal(12,2) NOT NULL,
  `purchaseIgstPer` decimal(12,2) NOT NULL,
  `purchaseIgstAmount` decimal(12,2) NOT NULL,
  `purchaseOtherTaxPer` decimal(12,2) NOT NULL,
  `purchaseOtherTaxAmount` decimal(12,2) NOT NULL,
  `purchaseDiscountPer` decimal(12,2) NOT NULL,
  `purchaseDiscountAmount` decimal(12,2) NOT NULL,
  `purchaseNetTotal` decimal(12,2) NOT NULL,
  `purchaseRemarks` varchar(255) NOT NULL,
  `purchaseBranchId` int(11) NOT NULL,
  `purchaseAddedBy` int(11) NOT NULL,
  `purchaseAddedOn` int(11) NOT NULL,
  `purchaseAddedIp` varchar(20) NOT NULL,
  `purchaseModifiedBy` int(11) NOT NULL,
  `purchaseModifiedOn` int(11) NOT NULL,
  `purchaseModifiedIp` varchar(20) NOT NULL,
  `purchaseDeletedBy` int(11) NOT NULL,
  `purchaseDeletedOn` int(11) NOT NULL,
  `purchaseDeletedIp` varchar(20) NOT NULL,
  `purchaseStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`purchaseId`),
  UNIQUE KEY `purchaseUniqId` (`purchaseUniqId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `purchase`
--


-- --------------------------------------------------------

--
-- Table structure for table `purchasedetails`
--

CREATE TABLE IF NOT EXISTS `purchasedetails` (
  `purchaseDetailsId` int(11) NOT NULL AUTO_INCREMENT,
  `purchaseDetailsUniqId` varchar(20) NOT NULL,
  `purchaseDetailsPurchaseId` int(11) NOT NULL,
  `purchaseDetailsProductId` int(11) NOT NULL,
  `purchaseDetailsQty` decimal(12,3) NOT NULL,
  `purchaseDetailsRate` decimal(12,2) NOT NULL,
  `purchaseDetailsAmount` decimal(12,2) NOT NULL,
  `purchaseDetailsAddedBy` int(11) NOT NULL,
  `purchaseDetailsAddedOn` int(11) NOT NULL,
  `purchaseDetailsAddedIp` varchar(20) NOT NULL,
  `purchaseDetailsModifiedBy` int(11) NOT NULL,
  `purchaseDetailsModifiedOn` int(11) NOT NULL,
  `purchaseDetailsModifiedIp` varchar(20) NOT NULL,
  `purchaseDetailsDeletedBy` int(11) NOT NULL,
  `purchaseDetailsDeletedOn` int(11) NOT NULL,
  `purchaseDetailsDeletedIp` varchar(20) NOT NULL,
  `purchaseDetailsStatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`purchaseDetailsId`),
  UNIQUE KEY `purchaseDetailsUniqId` (`purchaseDetailsUniqId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `purchasedetails`
--


-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplierId` int(11) NOT NULL AUTO_INCREMENT,
  `supplierUniqId` varchar(20) NOT NULL,
  `supplierCode` varchar(10) NOT NULL,
  `supplierName` varchar(100) NOT NULL,
  `supplierAddress` varchar(255) NOT NULL,
  `supplierMobileNo` varchar(13) NOT NULL,
  `supplierEmail` varchar(50) NOT NULL,
  `supplierGstNo` varchar(15) NOT NULL,
  `supplierAddedBy` int(11) NOT NULL,
  `supplierAddedOn` int(11) NOT NULL,
  `supplierAddedIp` varchar(20) NOT NULL,
  `supplierModifiedBy` int(11) NOT NULL,
  `supplierModifiedOn` int(11) NOT NULL,
  `supplierModifiedIp` varchar(20) NOT NULL,
  `supplierDeletedBy` int(11) NOT NULL,
  `supplierDeletedOn` int(11) NOT NULL,
  `supplierDeletedIp` varchar(20) NOT NULL,
  `supplierStatus` tinyint(4) NOT NULL,
  PRIMARY KEY (`supplierId`),
  UNIQUE KEY `supplierUniqId` (`supplierUniqId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplierId`, `supplierUniqId`, `supplierCode`, `supplierName`, `supplierAddress`, `supplierMobileNo`, `supplierEmail`, `supplierGstNo`, `supplierAddedBy`, `supplierAddedOn`, `supplierAddedIp`, `supplierModifiedBy`, `supplierModifiedOn`, `supplierModifiedIp`, `supplierDeletedBy`, `supplierDeletedOn`, `supplierDeletedIp`, `supplierStatus`) VALUES
(1, 'ke6b7YZ3QC1Forpj9OHD', 'S00001', 'Veera', 'Chennai', '9876543210', 'veera@gmail.com', '33ABCrggfh1fg12', 1, 1518713565, '192.168.1.7', 0, 0, '', 1, 1518713614, '192.168.1.7', 1),
(2, '0aRUoyOKVxL93teQwidG', 'S00001', 'Veera', 'Chennai', '9876543210', 'veera@gmail.com', '33ABCrggfh1fg12', 1, 1518713630, '192.168.1.7', 0, 0, '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_status` varchar(10) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_username`, `user_password`, `user_status`) VALUES
(1, 'VIJAY STS', 'vijay', '21232f2wq497a5808a27a5a743894a0e4a801fc3', 'active');
